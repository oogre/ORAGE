#pragma once

namespace reza {
namespace ui {

enum class FontSize {
    SMALL = 8,
    MEDIUM = 12,
    LARGE = 14
};

}
} // namespace reza::ui
