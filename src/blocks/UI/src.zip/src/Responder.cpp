#include "Responder.h"

using namespace reza::ui;
using namespace std;

Responder::Responder()
	: mName( "NULL" ), mID( -1 )
{
}

Responder::~Responder()
{
}
